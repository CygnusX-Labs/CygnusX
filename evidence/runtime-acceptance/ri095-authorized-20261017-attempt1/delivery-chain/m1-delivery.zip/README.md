# Project research delivery

Only explicitly associated, already existing research outputs are included.
Large raw sequencing files are reference-only. Missing evidence is listed in
ProjectDeliveryManifest.json; missing files have no placeholder bytes.
This archive does not establish scientific reproducibility. Reproduction: NOT_RUN.
Existing reports and their historical versions remain unchanged.

Offline verification (Python 3.11+, standard library only):
    python verify_project_delivery.py project-delivery.zip
You can additionally compare the downloaded ZIP SHA-256 with the authenticated
job status. Checksums are integrity checks, not digital signatures.
